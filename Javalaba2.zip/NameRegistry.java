import java.util.*;

/**
 * Класс NameRegistry — реестр объектов Name.
 * Позволяет:
 * - регистрировать имена по ключу
 * - получать имя по ключу
 * - проверять существование ключа
 * - получать все ключи и все значения
 * - очищать реестр
 * <p>
 * Этот класс удобен для централизованного хранения всех объектов Name
 * в программе и безопасного доступа к ним.
 */
public class NameRegistry {
    private final Map<String, Name> registry = new LinkedHashMap<>();

    public void register(String key, Name name) {
        if (key == null || name == null) return;
        if (registry.containsKey(key)) {
            System.out.println("Внимание: ключ '" + key + "' уже существует и будет перезаписан.");
        }
        registry.put(key, name);
    }

    public Name get(String key) {
        return registry.get(key);
    }

    public boolean contains(String key) {
        return registry.containsKey(key);
    }

    // Убрал неиспользуемые методы clear(), getAllKeys(), getAllValues()

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("NameRegistry: ");
        if (registry.isEmpty()) sb.append("(пусто)");
        else {
            registry.forEach((k, v) -> sb.append("\n").append(k).append(" -> ").append(v));
        }
        return sb.toString();
    }
}