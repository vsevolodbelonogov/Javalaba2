import java.util.Scanner;

/**
 * Класс Main — точка входа программы.
 * Реализует меню для запуска заданий по блокам.
 */
void main() {
    NameRegistry nameRegistry = new NameRegistry();
    try (Scanner scanner = new Scanner(System.in)) {
        while (true) {
            System.out.println("\n=== Главное меню ===");
            System.out.println("1 — Блок 1 (Имена)");
            System.out.println("2 — Блок 2 (Человек)");
            System.out.println("3 — Блок 3 (Города)");
            System.out.println("4 — Блок 4 (Расширенные имена и люди)");
            System.out.println("5 — Блок 5 (Кот)");
            System.out.println("0 — Выход");

            int block = Tasks.readIntInRange(scanner, "Выберите блок (0–5): ", 0, 5);
            if (block == 0) break;

            switch (block) {
                case 1 -> menuBlock1(scanner, nameRegistry);
                case 2 -> menuBlock2(scanner, nameRegistry);
                case 3 -> Tasks.task3Block3();
                case 4 -> menuBlock4(scanner);
                case 5 -> Tasks.task2Block5(scanner);
                default -> System.out.println("Неверный выбор.");
            }
        }
    }
}

void menuBlock1(Scanner scanner, NameRegistry registry) {
    System.out.println("\n--- Блок 1 (Имена) ---");
    int task = Tasks.readIntInRange(scanner, "3 — Создать три имени: ", 3, 3);
    if (task == 3) Tasks.task1Block1(registry);
}

void menuBlock2(Scanner scanner, NameRegistry registry) {
    System.out.println("\n--- Блок 2 (Человек) ---");
    int task = Tasks.readIntInRange(scanner, "2 — Человек с именем, 3 — Человек с отцом: ", 2, 3);
    if (task == 2) Tasks.task2Block2(registry);
    else Tasks.task3Block2();
}

void menuBlock4(Scanner scanner) {
    System.out.println("\n--- Блок 4 (Расширенные имена и люди) ---");
    int task = Tasks.readIntInRange(scanner, "5 — Создание имён, 6 — Создание людей: ", 5, 6);
    if (task == 5) Tasks.task5Block4();
    else Tasks.task6Block4();
}