/**
 * Класс Cat — описывает кота.
 * Хранит имя и умеет издавать звуки "мяу" в разных количествах.
 */
public record Cat(String name) {
    public Cat {
        name = (name == null || name.trim().isEmpty()) ? "(без имени)" : name.trim();
    }

    public void meow() {
        System.out.println(name + ": мяу!");
    }

    public void meow(int n) {
        if (n <= 0) {
            System.out.println(name + ": (молчание)");
            return;
        }
        if (n == 1) {
            meow();
            return;
        }
        System.out.println(name + ": " + "мяу-".repeat(n - 1) + "мяу!");
    }

    @Override
    public String toString() {
        return "кот: " + name;
    }
}