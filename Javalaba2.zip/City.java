import java.util.*;

/**
 * Класс City — описывает город.
 * Хранит имя города и соседние города с указанием стоимости пути.
 * Позволяет добавлять пути к другим городам и выводить информацию о соседях.
 */
public class City {
    private final String name;
    private final Map<City, Integer> neighbors = new LinkedHashMap<>();

    public City(String name) {
        this.name = (name == null) ? "" : name.trim();
    }

    // Убрал неиспользуемые геттеры

    public void addPathTo(City to, int cost) {
        if (to == null || cost < 0) return;
        neighbors.put(to, cost);
    }

    @Override
    public String toString() {
        if (neighbors.isEmpty()) return name + " -> (нет путей)";

        StringBuilder sb = new StringBuilder(name).append(" -> ");
        boolean first = true;
        for (Map.Entry<City, Integer> e : neighbors.entrySet()) {
            if (!first) sb.append(", ");
            sb.append(e.getKey().name).append(":").append(e.getValue());
            first = false;
        }
        return sb.toString();
    }
}