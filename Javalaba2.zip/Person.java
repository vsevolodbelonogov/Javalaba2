/**
 * Класс Person — описывает человека.
 * Хранит:
 * - объект Name
 * - рост (height)
 * - пол (Gender)
 * - ссылку на отца (для формирования фамилии и отчества)
 * <p>
 * Предоставляет методы для генерации отчества и фамилии по отцу.
 */
public class Person {
    public enum Gender { MALE, FEMALE }

    private final Name name;
    private final int height;
    private final Gender gender;
    private Person father;

    public Person(Name name, int height) {
        this(name, height, null, Gender.MALE);
    }

    public Person(Name name, int height, Person father) {
        this(name, height, father, Gender.MALE);
    }

    public Person(Name name, int height, Person father, Gender gender) {
        validateHeight(height);
        this.name = (name != null) ? name : new Name("");
        this.height = height;
        this.gender = gender;
        setFather(father);
    }

    private void validateHeight(int height) {
        if (height <= 0) {
            throw new IllegalArgumentException("Рост должен быть положительным числом");
        }
    }

    public static Person fromNameStringAndHeight(String givenName, int height) {
        return new Person(new Name(givenName), height);
    }

    public static Person fromNameStringHeightAndFather(String givenName, int height, Person father) {
        return new Person(new Name(givenName), height, father);
    }

    public Person getFather() {
        return father;
    }

    public void setFather(Person father) {
        validateFather(father);
        this.father = father;
        applyFatherDataIfNeeded();
    }

    private void validateFather(Person father) {
        if (father == this) {
            throw new IllegalArgumentException("Человек не может быть своим отцом");
        }

        Person current = father;
        while (current != null) {
            if (current == this) {
                throw new IllegalArgumentException("Обнаружена циклическая ссылка в родословной");
            }
            current = current.getFather();
        }
    }

    private void applyFatherDataIfNeeded() {
        if (father == null) return;

        // Упрощенная логика наследования фамилии
        if (isNullOrEmpty(name.getSurname()) && !isNullOrEmpty(father.name.getSurname())) {
            this.name.setSurname(father.name.getSurname());
        }

        if (isNullOrEmpty(name.getPatronymic()) && !isNullOrEmpty(father.name.getGivenName())) {
            this.name.setPatronymic(generatePatronymic(father.name.getGivenName(), this.gender));
        }
    }

    private static boolean isNullOrEmpty(String s) {
        return s == null || s.isEmpty();
    }

    private static String generatePatronymic(String fatherGivenName, Gender gender) {
        if (fatherGivenName == null || fatherGivenName.isEmpty()) return null;

        String base = fatherGivenName.trim();
        if (base.endsWith("й") || base.endsWith("ь")) {
            base = base.substring(0, base.length() - 1);
        }

        return gender == Gender.MALE ? base + "ович" : base + "овна";
    }

    @Override
    public String toString() {
        return name.toString() + ", " + height;
    }
}