import java.util.Scanner;

/**
 * Класс Tasks — содержит методы для выполнения заданий по блокам.
 * Использует объекты Name, Person, City, Cat и реестр NameRegistry.
 */
public class Tasks {

    public static int readIntInRange(Scanner scanner, String prompt, int min, int max) {
        while (true) {
            System.out.print(prompt);
            String line = scanner.nextLine().trim();
            try {
                int v = Integer.parseInt(line);
                if (v < min || v > max) {
                    System.out.println("Введите число в диапазоне от " + min + " до " + max + ".");
                    continue;
                }
                return v;
            } catch (NumberFormatException ex) {
                System.out.println("Неверный ввод: требуется целое число.");
            }
        }
    }

    public static int readPositiveInt(Scanner scanner, String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = scanner.nextLine().trim();
            try {
                int v = Integer.parseInt(line);
                if (v <= 0) {
                    System.out.println("Введите положительное целое число.");
                    continue;
                }
                return v;
            } catch (NumberFormatException ex) {
                System.out.println("Неверный ввод: требуется целое число.");
            }
        }
    }

    // Убрал неиспользуемый метод readNonEmptyString

    // ---------------------------
    // Методы заданий
    // ---------------------------

    public static void task1Block1(NameRegistry registry) {
        System.out.println("\n[Блок 1.3] Создание имён.");
        Name cleo = new Name("Клеопатра");
        Name pushkin = new Name("Александр", "Пушкин", "Сергеевич");
        Name mayakovsky = new Name("Владимир", "Маяковский"); // Исправлено: mayakov -> mayakovsky

        registry.register("CLEOPATRA", cleo);
        registry.register("PUSHKIN_ALEXANDR_SERGEEVICH", pushkin);
        registry.register("MAYAKOVSKY_VLADIMIR", mayakovsky); // Исправлено: MAYAKOV -> MAYAKOVSKY

        System.out.println(cleo);
        System.out.println(pushkin);
        System.out.println(mayakovsky);
    }

    public static void task2Block2(NameRegistry registry) {
        if (!registry.contains("CLEOPATRA")) task1Block1(registry);

        Person p1 = new Person(registry.get("CLEOPATRA"), 152, null, Person.Gender.FEMALE);
        Person p2 = new Person(registry.get("PUSHKIN_ALEXANDR_SERGEEVICH"), 167, null, Person.Gender.MALE);
        Person p3 = new Person(registry.get("MAYAKOVSKY_VLADIMIR"), 189, null, Person.Gender.MALE); // Исправлено: MAYAKOV -> MAYAKOVSKY

        System.out.println(p1);
        System.out.println(p2);
        System.out.println(p3);
    }

    public static void task3Block2() {
        Name ivanName = new Name("Иван", "Чудов");
        Name petrName = new Name("Пётр", "Чудов");
        Name borisName = new Name("Борис");

        Person ivan = new Person(ivanName, 180, null, Person.Gender.MALE);
        Person petr = new Person(petrName, 175, ivan, Person.Gender.MALE);
        Person boris = new Person(borisName, 170, petr, Person.Gender.MALE);

        System.out.println(ivan);
        System.out.println(petr);
        System.out.println(boris);
    }

    public static void task3Block3() {
        City A = new City("A");
        City B = new City("B");
        City C = new City("C");
        City D = new City("D");
        City E = new City("E");
        City F = new City("F");

        A.addPathTo(B, 5); B.addPathTo(A, 5);
        B.addPathTo(C, 3); C.addPathTo(B, 3);
        C.addPathTo(D, 4); D.addPathTo(C, 4);
        A.addPathTo(D, 6); D.addPathTo(A, 6);
        F.addPathTo(E, 2); E.addPathTo(F, 2);
        D.addPathTo(E, 2);
        F.addPathTo(B, 1);
        A.addPathTo(F, 1);

        System.out.println(A); System.out.println(B); System.out.println(C);
        System.out.println(D); System.out.println(E); System.out.println(F);
    }

    public static void task5Block4() {
        System.out.println(new Name("Клеопатра"));
        System.out.println(new Name("Сергей", "Пушкин", "Сергеевич"));
        System.out.println(new Name("Владимир", "Маяковский"));
        System.out.println(new Name("Христофор", "Бонифатьевич"));
    }

    public static void task6Block4() {
        Person lev = Person.fromNameStringAndHeight("Лев", 170);
        System.out.println(lev);

        Person sergey = new Person(new Name("Сергей", "Пушкин"), 168, lev, Person.Gender.MALE);
        System.out.println(sergey);

        Person alex = Person.fromNameStringHeightAndFather("Александр", 167, sergey);
        System.out.println(alex);
    }

    public static void task2Block5(Scanner scanner) {
        Cat barsik = new Cat("Барсик");
        System.out.println("Создан: " + barsik);
        barsik.meow();
        int n = readPositiveInt(scanner, "Сколько раз коту мяукнуть? ");
        barsik.meow(n);
    }
}