/**
 * Класс Name — хранит данные об имени человека:
 * - имя (givenName)
 * - фамилия (surname)
 * - отчество (patronymic)
 * <p>
 * Предоставляет методы для получения и изменения этих данных,
 * а также красивое строковое представление.
 */
public class Name {
    private final String givenName; // Сделал final
    private String surname;
    private String patronymic;

    public Name(String givenName) {
        this(givenName, null, null);
    }

    public Name(String givenName, String surname) {
        this(givenName, surname, null);
    }

    public Name(String givenName, String surname, String patronymic) {
        this.givenName = normalize(givenName);
        this.surname = normalize(surname);
        this.patronymic = normalize(patronymic);
    }

    private static String normalize(String s) {
        return (s == null || s.trim().isEmpty()) ? null : s.trim();
    }

    public String getGivenName() {
        return givenName;
    }

    public String getSurname() {
        return surname;
    }

    public String getPatronymic() {
        return patronymic;
    }

    public void setSurname(String surname) {
        this.surname = normalize(surname);
    }

    public void setPatronymic(String patronymic) {
        this.patronymic = normalize(patronymic);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        if (surname != null) sb.append(surname).append(" ");
        if (givenName != null) sb.append(givenName).append(" ");
        if (patronymic != null) sb.append(patronymic);
        return sb.toString().trim();
    }
}